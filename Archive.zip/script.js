document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to My Blog!');

    const scrollToTopButton = document.createElement('button');
    scrollToTopButton.textContent = '↑';
    scrollToTopButton.className = 'scroll-to-top';
    scrollToTopButton.style.position = 'fixed';
    scrollToTopButton.style.bottom = '20px';
    scrollToTopButton.style.right = '20px';
    scrollToTopButton.style.padding = '10px';
    scrollToTopButton.style.borderRadius = '50%';
    scrollToTopButton.style.border = 'none';
    scrollToTopButton.style.backgroundColor = '#0071e3';
    scrollToTopButton.style.color = '#fff';
    scrollToTopButton.style.cursor = 'pointer';
    document.body.appendChild(scrollToTopButton);

    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            scrollToTopButton.classList.add('visible');
        } else {
            scrollToTopButton.classList.remove('visible');
        }
    });

    scrollToTopButton.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Example: Function to dynamically load blog posts
    function loadBlogPosts() {
        // Fetch or generate blog post content dynamically
        const posts = [
            { title: "How I Built This Website", content: "This post explains the technologies..." },
            // Add more posts here
        ];

        const blogSection = document.getElementById('blog');
        posts.forEach(post => {
            const article = document.createElement('article');
            article.innerHTML = `<h3>${post.title}</h3><p>${post.content}</p>`;
            blogSection.appendChild(article);
        });
    }

    // Call the function to load posts
    loadBlogPosts();
}); 